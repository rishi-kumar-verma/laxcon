@extends('layouts.app')

@section('content')
    @extends('login')
@endsection