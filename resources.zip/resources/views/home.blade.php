@extends('layouts.app')

@section('content')
    <!-- @extends('grades') -->
@endsection
